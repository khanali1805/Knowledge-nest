﻿import { TaxonomyManager } from "@/components/admin/taxonomy/taxonomy-manager";
const categories = [
  {
    id: 1,
    name: "Finance",
    slug: "finance",
    description: "Personal finance, banking, investing and economic topics.",
    articleCount: 0,
  },
  {
    id: 2,
    name: "Science",
    slug: "science",
    description: "Scientific discoveries, research and explanations.",
    articleCount: 0,
  },
  {
    id: 3,
    name: "Technology",
    slug: "technology",
    description: "Technology news, guides and digital innovation.",
    articleCount: 0,
  },
  {
    id: 4,
    name: "Artificial Intelligence",
    slug: "artificial-intelligence",
    description: "Artificial intelligence tools, research and applications.",
    articleCount: 0,
  },
  {
    id: 5,
    name: "Health",
    slug: "health",
    description: "General health education and wellness information.",
    articleCount: 0,
  },
  {
    id: 6,
    name: "Education",
    slug: "education",
    description: "Learning resources, study guidance and education updates.",
    articleCount: 0,
  },
  {
    id: 7,
    name: "Business",
    slug: "business",
    description: "Business strategy, entrepreneurship and market insights.",
    articleCount: 0,
  },
  {
    id: 8,
    name: "History",
    slug: "history",
    description: "Historical events, people and civilizations.",
    articleCount: 0,
  },
  {
    id: 9,
    name: "Environment",
    slug: "environment",
    description: "Climate, sustainability and environmental knowledge.",
    articleCount: 0,
  },
  {
    id: 10,
    name: "Space",
    slug: "space",
    description: "Space exploration, astronomy and the universe.",
    articleCount: 0,
  },
  {
    id: 11,
    name: "Psychology",
    slug: "psychology",
    description: "Human behavior, thinking and psychology education.",
    articleCount: 0,
  },
  {
    id: 12,
    name: "General Knowledge",
    slug: "general-knowledge",
    description: "Useful facts and educational general knowledge.",
    articleCount: 0,
  },
];
export default function CategoriesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Categories</h1>
        <p className="text-muted-foreground mt-2 text-sm">
          Organize articles into primary website sections.
        </p>
      </div>
      <TaxonomyManager type="category" initialItems={categories} />
    </div>
  );
}
