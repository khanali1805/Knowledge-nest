﻿import { PagesManager } from "@/components/admin/pages/pages-manager";
export default function PagesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Pages</h1>
        <p className="text-muted-foreground mt-2 text-sm">
          Manage permanent website information and policy pages.
        </p>
      </div>
      <PagesManager />
    </div>
  );
}
