﻿import { SettingsForm } from "@/components/admin/settings/settings-form";
export default function SettingsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Settings</h1>
        <p className="text-muted-foreground mt-2 text-sm">
          Configure your website preferences.
        </p>
      </div>
      <SettingsForm />
    </div>
  );
}
