﻿import { TaxonomyManager } from "@/components/admin/taxonomy/taxonomy-manager";
const tags = [
  {
    id: 1,
    name: "Latest",
    slug: "latest",
    description: "Recently published and updated content.",
    articleCount: 0,
  },
  {
    id: 2,
    name: "Guide",
    slug: "guide",
    description: "Detailed educational guides and tutorials.",
    articleCount: 0,
  },
  {
    id: 3,
    name: "Explained",
    slug: "explained",
    description: "Complex subjects explained clearly.",
    articleCount: 0,
  },
];
export default function TagsPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Tags</h1>
        <p className="text-muted-foreground mt-2 text-sm">
          Add supporting labels for article discovery and organization.
        </p>
      </div>
      <TaxonomyManager type="tag" initialItems={tags} />
    </div>
  );
}
