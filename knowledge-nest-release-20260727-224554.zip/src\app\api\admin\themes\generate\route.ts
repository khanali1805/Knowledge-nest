﻿import { NextResponse } from "next/server";
import { generateThemeConfiguration } from "@/lib/theme/ai-generator";
import { saveTheme } from "@/lib/theme/theme-store";
import type { ThemeConfiguration } from "@/lib/theme/types";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
type GenerateThemeRequest = {
  prompt?: string;
  theme?: ThemeConfiguration;
};
export async function POST(request: Request) {
  try {
    const body = (await request.json()) as GenerateThemeRequest;
    if (!body.theme) {
      return NextResponse.json(
        {
          message: "A base theme is required.",
        },
        {
          status: 400,
        },
      );
    }
    const generatedTheme = generateThemeConfiguration(
      {
        ...body.theme,
        id: `${body.theme.niche}-ai-${Date.now()}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      body.prompt?.trim() || body.theme.niche,
    );
    const savedTheme = await saveTheme(generatedTheme);
    return NextResponse.json(
      {
        theme: savedTheme,
      },
      {
        status: 201,
      },
    );
  } catch (error) {
    return NextResponse.json(
      {
        message: error instanceof Error ? error.message : "Unable to generate the theme.",
      },
      {
        status: 400,
      },
    );
  }
}
