﻿import type { MetadataRoute } from "next";
import { getSiteUrl } from "@/lib/site-url";
export default function browserconfig(): MetadataRoute.Manifest {
  const siteUrl = getSiteUrl();
  return {
    name: "Knowledge Nest",
    short_name: "Knowledge Nest",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#ffffff",
    icons: [
      {
        src: `${siteUrl}/icon.svg`,
        sizes: "any",
        type: "image/svg+xml",
      },
    ],
  };
}
