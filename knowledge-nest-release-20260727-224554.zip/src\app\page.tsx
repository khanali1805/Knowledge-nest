﻿import type { Metadata } from "next";
import { DynamicHomepage } from "@/components/site/dynamic-homepage";
import { getActiveTheme } from "@/lib/theme/theme-store";
export const dynamic = "force-dynamic";
export async function generateMetadata(): Promise<Metadata> {
  const theme = await getActiveTheme();
  return {
    title: theme.name,
    description: `Explore the latest ${theme.niche} articles, guides and updates on ${theme.name}.`,
  };
}
export default function HomePage() {
  return <DynamicHomepage />;
}
