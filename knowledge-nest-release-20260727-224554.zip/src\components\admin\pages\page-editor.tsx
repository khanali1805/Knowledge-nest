﻿"use client";
import Link from "next/link";
import { ArrowLeft, Eye, Save, Send } from "lucide-react";
import { type FormEvent, useMemo, useState } from "react";
type PageEditorProps = {
  mode: "create" | "edit";
};
function createSlug(value: string) {
  return value
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}
export function PageEditor({ mode }: PageEditorProps) {
  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [content, setContent] = useState("");
  const [status, setStatus] = useState("draft");
  const [seoTitle, setSeoTitle] = useState("");
  const [seoDescription, setSeoDescription] = useState("");
  const wordCount = useMemo(() => {
    const cleanContent = content.trim();
    if (!cleanContent) {
      return 0;
    }
    return cleanContent.split(/\s+/).length;
  }, [content]);
  function handleTitleChange(value: string) {
    setTitle(value);
    if (mode === "create") {
      setSlug(createSlug(value));
    }
  }
  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
  }
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex flex-col justify-between gap-4 xl:flex-row xl:items-center">
        <div className="flex items-start gap-3">
          <Link
            href="/admin/pages"
            aria-label="Back to pages"
            className="border-border hover:bg-muted mt-1 rounded-lg border p-2 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">
              {mode === "create" ? "New Page" : "Edit Page"}
            </h1>
            <p className="text-muted-foreground mt-1 text-sm">
              Create and manage a website information page.
            </p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            className="border-border hover:bg-muted inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-colors"
          >
            <Eye className="h-4 w-4" />
            Preview
          </button>
          <button
            type="submit"
            className="border-border hover:bg-muted inline-flex items-center gap-2 rounded-lg border px-4 py-2 text-sm font-medium transition-colors"
          >
            <Save className="h-4 w-4" />
            Save Draft
          </button>
          <button
            type="submit"
            className="bg-foreground text-background inline-flex items-center gap-2 rounded-lg px-4 py-2 text-sm font-medium"
          >
            <Send className="h-4 w-4" />
            Publish
          </button>
        </div>
      </div>
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_340px]">
        <div className="space-y-6">
          <section className="border-border bg-background rounded-xl border p-5 shadow-sm sm:p-6">
            <div className="space-y-5">
              <div>
                <label htmlFor="page-title" className="mb-2 block text-sm font-semibold">
                  Page Title
                </label>
                <input
                  id="page-title"
                  value={title}
                  onChange={(event) => handleTitleChange(event.target.value)}
                  placeholder="Enter page title"
                  required
                  className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-3 text-lg font-semibold outline-none focus:ring-4"
                />
              </div>
              <div>
                <label htmlFor="page-slug" className="mb-2 block text-sm font-semibold">
                  URL Slug
                </label>
                <input
                  id="page-slug"
                  value={slug}
                  onChange={(event) => setSlug(createSlug(event.target.value))}
                  placeholder="page-url-slug"
                  required
                  className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 text-sm outline-none focus:ring-4"
                />
              </div>
            </div>
          </section>
          <section className="border-border bg-background rounded-xl border shadow-sm">
            <div className="border-border border-b p-4">
              <h2 className="font-semibold">Page Content</h2>
              <p className="text-muted-foreground mt-1 text-xs">
                {wordCount} {wordCount === 1 ? "word" : "words"}
              </p>
            </div>
            <textarea
              value={content}
              onChange={(event) => setContent(event.target.value)}
              placeholder="Write the page content..."
              required
              rows={22}
              className="bg-background min-h-[520px] w-full resize-y rounded-b-xl p-5 text-sm leading-7 outline-none sm:p-6"
            />
          </section>
          <section className="border-border bg-background rounded-xl border p-5 shadow-sm sm:p-6">
            <h2 className="text-lg font-semibold">Search Engine Optimization</h2>
            <div className="mt-5 space-y-5">
              <div>
                <label
                  htmlFor="page-seo-title"
                  className="mb-2 block text-sm font-medium"
                >
                  SEO Title
                </label>
                <input
                  id="page-seo-title"
                  value={seoTitle}
                  onChange={(event) => setSeoTitle(event.target.value)}
                  maxLength={60}
                  placeholder="Search result title"
                  className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 text-sm outline-none focus:ring-4"
                />
                <p className="text-muted-foreground mt-2 text-right text-xs">
                  {seoTitle.length}/60
                </p>
              </div>
              <div>
                <label
                  htmlFor="page-seo-description"
                  className="mb-2 block text-sm font-medium"
                >
                  Meta Description
                </label>
                <textarea
                  id="page-seo-description"
                  value={seoDescription}
                  onChange={(event) => setSeoDescription(event.target.value)}
                  maxLength={160}
                  rows={3}
                  placeholder="Search result description"
                  className="border-border bg-background focus:ring-foreground/20 w-full resize-y rounded-lg border px-4 py-3 text-sm outline-none focus:ring-4"
                />
                <p className="text-muted-foreground mt-2 text-right text-xs">
                  {seoDescription.length}/160
                </p>
              </div>
            </div>
          </section>
        </div>
        <aside className="space-y-6">
          <section className="border-border bg-background rounded-xl border p-5 shadow-sm">
            <h2 className="font-semibold">Publishing</h2>
            <div className="mt-4">
              <label htmlFor="page-status" className="mb-2 block text-sm font-medium">
                Status
              </label>
              <select
                id="page-status"
                value={status}
                onChange={(event) => setStatus(event.target.value)}
                className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-3 py-2.5 text-sm outline-none focus:ring-4"
              >
                <option value="draft">Draft</option>
                <option value="published">Published</option>
              </select>
            </div>
          </section>
          <section className="border-border bg-background rounded-xl border p-5 shadow-sm">
            <h2 className="font-semibold">Page URL</h2>
            <p className="text-muted-foreground mt-3 text-sm break-all">
              /{slug || "page-url-slug"}
            </p>
          </section>
        </aside>
      </div>
    </form>
  );
}
