﻿"use client";
import { Save } from "lucide-react";
import { useState } from "react";
export function SettingsForm() {
  const [siteName, setSiteName] = useState("Knowledge Nest");
  const [tagline, setTagline] = useState("Trusted knowledge for everyone.");
  const [siteUrl, setSiteUrl] = useState("https://example.com");
  const [adminEmail, setAdminEmail] = useState("admin@example.com");
  const [postsPerPage, setPostsPerPage] = useState("12");
  const [language, setLanguage] = useState("en");
  const [timezone, setTimezone] = useState("UTC");
  const [indexSite, setIndexSite] = useState(true);
  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
  }
  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <section className="border-border bg-background rounded-xl border p-6 shadow-sm">
        <h2 className="text-xl font-semibold">General Settings</h2>
        <div className="mt-6 grid gap-5 md:grid-cols-2">
          <div>
            <label className="mb-2 block text-sm font-medium">Site Name</label>
            <input
              value={siteName}
              onChange={(event) => setSiteName(event.target.value)}
              className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 outline-none focus:ring-4"
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Site URL</label>
            <input
              value={siteUrl}
              onChange={(event) => setSiteUrl(event.target.value)}
              className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 outline-none focus:ring-4"
            />
          </div>
          <div className="md:col-span-2">
            <label className="mb-2 block text-sm font-medium">Tagline</label>
            <input
              value={tagline}
              onChange={(event) => setTagline(event.target.value)}
              className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 outline-none focus:ring-4"
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Admin Email</label>
            <input
              type="email"
              value={adminEmail}
              onChange={(event) => setAdminEmail(event.target.value)}
              className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 outline-none focus:ring-4"
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Posts Per Page</label>
            <input
              type="number"
              value={postsPerPage}
              onChange={(event) => setPostsPerPage(event.target.value)}
              className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 outline-none focus:ring-4"
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Language</label>
            <select
              value={language}
              onChange={(event) => setLanguage(event.target.value)}
              className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 outline-none focus:ring-4"
            >
              <option value="en">English</option>
            </select>
          </div>
          <div>
            <label className="mb-2 block text-sm font-medium">Time Zone</label>
            <select
              value={timezone}
              onChange={(event) => setTimezone(event.target.value)}
              className="border-border bg-background focus:ring-foreground/20 w-full rounded-lg border px-4 py-2.5 outline-none focus:ring-4"
            >
              <option value="UTC">UTC</option>
            </select>
          </div>
          <div className="md:col-span-2">
            <label className="flex items-center gap-3 text-sm font-medium">
              <input
                type="checkbox"
                checked={indexSite}
                onChange={(event) => setIndexSite(event.target.checked)}
                className="h-4 w-4"
              />
              Allow search engines to index the website
            </label>
          </div>
        </div>
      </section>
      <div className="flex justify-end">
        <button
          type="submit"
          className="bg-foreground text-background inline-flex items-center gap-2 rounded-lg px-5 py-2.5 text-sm font-medium"
        >
          <Save className="h-4 w-4" />
          Save Settings
        </button>
      </div>
    </form>
  );
}
