﻿import { JsonLd } from "@/components/site/seo/json-ld";
import { getSiteUrl } from "@/lib/site-url";
export function OrganizationJsonLd() {
  const siteUrl = getSiteUrl();
  return (
    <JsonLd
      data={{
        "@context": "https://schema.org",
        "@type": "Organization",
        name: "Knowledge Nest",
        url: siteUrl,
        logo: `${siteUrl}/icon.svg`,
      }}
    />
  );
}
