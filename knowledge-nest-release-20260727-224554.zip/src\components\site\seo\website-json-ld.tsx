﻿import { JsonLd } from "@/components/site/seo/json-ld";
import { getSiteUrl } from "@/lib/site-url";
export function WebsiteJsonLd() {
  const siteUrl = getSiteUrl();
  return (
    <JsonLd
      data={{
        "@context": "https://schema.org",
        "@type": "WebSite",
        name: "Knowledge Nest",
        url: siteUrl,
        description:
          "Educational articles across finance, science, technology, health, education and other knowledge categories.",
        potentialAction: {
          "@type": "SearchAction",
          target: {
            "@type": "EntryPoint",
            urlTemplate: `${siteUrl}/search?q={search_term_string}`,
          },
          "query-input": "required name=search_term_string",
        },
      }}
    />
  );
}
