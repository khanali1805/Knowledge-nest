﻿import type {
  ThemeColourPalette,
  ThemeConfiguration,
  ThemeLayout,
  ThemeNiche,
  ThemeTypography,
} from "@/lib/theme/types";
const colourPalettes: Record<string, ThemeColourPalette> = {
  professional: {
    background: "#f8fafc",
    foreground: "#0f172a",
    primary: "#1d4ed8",
    secondary: "#334155",
    accent: "#f59e0b",
    muted: "#e2e8f0",
    border: "#cbd5e1",
  },
  modern: {
    background: "#ffffff",
    foreground: "#111827",
    primary: "#7c3aed",
    secondary: "#2563eb",
    accent: "#06b6d4",
    muted: "#f3f4f6",
    border: "#d1d5db",
  },
  luxury: {
    background: "#0c0a09",
    foreground: "#fafaf9",
    primary: "#d4af37",
    secondary: "#78716c",
    accent: "#f5d06f",
    muted: "#1c1917",
    border: "#44403c",
  },
  natural: {
    background: "#f7fee7",
    foreground: "#365314",
    primary: "#4d7c0f",
    secondary: "#166534",
    accent: "#ca8a04",
    muted: "#ecfccb",
    border: "#bef264",
  },
  energetic: {
    background: "#fff7ed",
    foreground: "#431407",
    primary: "#ea580c",
    secondary: "#dc2626",
    accent: "#eab308",
    muted: "#ffedd5",
    border: "#fdba74",
  },
};
const typographyPresets: Record<string, ThemeTypography> = {
  editorial: {
    headingFont: "Georgia",
    bodyFont: "Arial",
    headingWeight: 700,
    bodyWeight: 400,
  },
  modern: {
    headingFont: "Inter",
    bodyFont: "Inter",
    headingWeight: 800,
    bodyWeight: 400,
  },
  elegant: {
    headingFont: "Times New Roman",
    bodyFont: "Arial",
    headingWeight: 700,
    bodyWeight: 400,
  },
  technical: {
    headingFont: "Arial",
    bodyFont: "Verdana",
    headingWeight: 700,
    bodyWeight: 400,
  },
};
function hashText(value: string): number {
  return Array.from(value).reduce(
    (total, character) => total + character.charCodeAt(0),
    0,
  );
}
export function generateColourPalette(
  prompt: string,
  niche: ThemeNiche,
): ThemeColourPalette {
  const input = `${prompt} ${niche}`.toLowerCase();
  if (input.includes("luxury") || input.includes("premium") || input.includes("gold")) {
    return structuredClone(colourPalettes.luxury);
  }
  if (
    input.includes("nature") ||
    input.includes("green") ||
    input.includes("agriculture") ||
    input.includes("health")
  ) {
    return structuredClone(colourPalettes.natural);
  }
  if (
    input.includes("sport") ||
    input.includes("food") ||
    input.includes("energy") ||
    input.includes("bright")
  ) {
    return structuredClone(colourPalettes.energetic);
  }
  if (
    input.includes("business") ||
    input.includes("finance") ||
    input.includes("professional")
  ) {
    return structuredClone(colourPalettes.professional);
  }
  return structuredClone(colourPalettes.modern);
}
export function generateTypography(prompt: string, niche: ThemeNiche): ThemeTypography {
  const input = `${prompt} ${niche}`.toLowerCase();
  if (
    input.includes("news") ||
    input.includes("editorial") ||
    input.includes("magazine")
  ) {
    return structuredClone(typographyPresets.editorial);
  }
  if (input.includes("luxury") || input.includes("fashion") || input.includes("beauty")) {
    return structuredClone(typographyPresets.elegant);
  }
  if (
    input.includes("technology") ||
    input.includes("science") ||
    input.includes("gaming") ||
    input.includes("ai")
  ) {
    return structuredClone(typographyPresets.technical);
  }
  return structuredClone(typographyPresets.modern);
}
export function generateLayout(prompt: string, niche: ThemeNiche): ThemeLayout {
  const input = `${prompt} ${niche}`.toLowerCase();
  if (input.includes("minimal") || input.includes("simple") || input.includes("clean")) {
    return "minimal";
  }
  if (
    input.includes("business") ||
    input.includes("finance") ||
    input.includes("corporate")
  ) {
    return "business";
  }
  if (
    input.includes("fashion") ||
    input.includes("beauty") ||
    input.includes("photography") ||
    input.includes("visual")
  ) {
    return "visual";
  }
  if (input.includes("news") || input.includes("editorial")) {
    return "editorial";
  }
  if (
    input.includes("technology") ||
    input.includes("gaming") ||
    input.includes("grid")
  ) {
    return "grid";
  }
  return "magazine";
}
export function generateThemeConfiguration(
  baseTheme: ThemeConfiguration,
  prompt: string,
): ThemeConfiguration {
  const generatedAt = new Date().toISOString();
  const seed = hashText(`${prompt}-${baseTheme.niche}`);
  const generatedSections = baseTheme.sections
    .map((section, index) => ({
      ...section,
      position: ((index + seed) % baseTheme.sections.length) + 1,
    }))
    .sort((first, second) => first.position - second.position)
    .map((section, index) => ({
      ...section,
      position: index + 1,
    }));
  return {
    ...structuredClone(baseTheme),
    name: prompt.trim() ? `${baseTheme.name} AI` : `${baseTheme.name} Generated`,
    colours: generateColourPalette(prompt, baseTheme.niche),
    typography: generateTypography(prompt, baseTheme.niche),
    layout: generateLayout(prompt, baseTheme.niche),
    sections: generatedSections,
    version: baseTheme.version + 1,
    isActive: false,
    updatedAt: generatedAt,
  };
}
