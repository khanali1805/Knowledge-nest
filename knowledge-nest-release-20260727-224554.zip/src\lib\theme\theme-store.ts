﻿import { promises as fs } from "node:fs";
import path from "node:path";
import { themePresets } from "@/lib/theme/presets";
import type { ThemeBackup, ThemeConfiguration, ThemeStore } from "@/lib/theme/types";
const themeDirectory = path.join(process.cwd(), "data");
const themeFilePath = path.join(themeDirectory, "theme-store.json");
function createInitialStore(): ThemeStore {
  const themes = structuredClone(themePresets);
  const activeTheme = themes.find((theme) => theme.isActive) ?? themes[0];
  return {
    activeThemeId: activeTheme.id,
    themes: themes.map((theme) => ({
      ...theme,
      isActive: theme.id === activeTheme.id,
    })),
    backups: [],
  };
}
async function ensureThemeStore(): Promise<void> {
  await fs.mkdir(themeDirectory, {
    recursive: true,
  });
  try {
    await fs.access(themeFilePath);
  } catch {
    await writeThemeStore(createInitialStore());
  }
}
export async function readThemeStore(): Promise<ThemeStore> {
  await ensureThemeStore();
  const rawContent = await fs.readFile(themeFilePath, "utf8");
  const parsedStore = JSON.parse(rawContent) as ThemeStore;
  return parsedStore;
}
export async function writeThemeStore(store: ThemeStore): Promise<void> {
  await fs.mkdir(themeDirectory, {
    recursive: true,
  });
  await fs.writeFile(themeFilePath, JSON.stringify(store, null, 2), "utf8");
}
export async function getActiveTheme(): Promise<ThemeConfiguration> {
  const store = await readThemeStore();
  return (
    store.themes.find((theme) => theme.id === store.activeThemeId) ?? store.themes[0]
  );
}
export async function saveTheme(theme: ThemeConfiguration): Promise<ThemeConfiguration> {
  const store = await readThemeStore();
  const existingIndex = store.themes.findIndex(
    (existingTheme) => existingTheme.id === theme.id,
  );
  const nextTheme: ThemeConfiguration = {
    ...theme,
    version:
      existingIndex >= 0
        ? Math.max(theme.version, store.themes[existingIndex].version + 1)
        : Math.max(theme.version, 1),
    updatedAt: new Date().toISOString(),
  };
  if (existingIndex >= 0) {
    store.themes[existingIndex] = nextTheme;
  } else {
    store.themes.push(nextTheme);
  }
  if (nextTheme.isActive) {
    store.activeThemeId = nextTheme.id;
    store.themes = store.themes.map((storedTheme) => ({
      ...storedTheme,
      isActive: storedTheme.id === nextTheme.id,
    }));
  }
  await writeThemeStore(store);
  return store.themes.find((storedTheme) => storedTheme.id === nextTheme.id) ?? nextTheme;
}
export async function activateTheme(themeId: string): Promise<ThemeConfiguration> {
  const store = await readThemeStore();
  const selectedTheme = store.themes.find((theme) => theme.id === themeId);
  if (!selectedTheme) {
    throw new Error("Theme was not found.");
  }
  store.activeThemeId = themeId;
  store.themes = store.themes.map((theme) => ({
    ...theme,
    isActive: theme.id === themeId,
    updatedAt: theme.id === themeId ? new Date().toISOString() : theme.updatedAt,
  }));
  await writeThemeStore(store);
  return store.themes.find((theme) => theme.id === themeId)!;
}
export async function deleteTheme(themeId: string): Promise<void> {
  const store = await readThemeStore();
  if (store.themes.length <= 1) {
    throw new Error("The final theme cannot be deleted.");
  }
  if (store.activeThemeId === themeId) {
    throw new Error("The active theme cannot be deleted.");
  }
  store.themes = store.themes.filter((theme) => theme.id !== themeId);
  await writeThemeStore(store);
}
export async function createThemeBackup(
  themeId: string,
  name?: string,
): Promise<ThemeBackup> {
  const store = await readThemeStore();
  const theme = store.themes.find((storedTheme) => storedTheme.id === themeId);
  if (!theme) {
    throw new Error("Theme was not found.");
  }
  const backup: ThemeBackup = {
    id: `backup-${Date.now()}`,
    name: name?.trim() || `${theme.name} Backup`,
    createdAt: new Date().toISOString(),
    theme: structuredClone(theme),
  };
  store.backups.unshift(backup);
  await writeThemeStore(store);
  return backup;
}
export async function restoreThemeBackup(backupId: string): Promise<ThemeConfiguration> {
  const store = await readThemeStore();
  const backup = store.backups.find((storedBackup) => storedBackup.id === backupId);
  if (!backup) {
    throw new Error("Theme backup was not found.");
  }
  const restoredTheme: ThemeConfiguration = {
    ...structuredClone(backup.theme),
    id: `${backup.theme.niche}-restored-${Date.now()}`,
    name: `${backup.theme.name} Restored`,
    isActive: false,
    version: backup.theme.version + 1,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
  store.themes.push(restoredTheme);
  await writeThemeStore(store);
  return restoredTheme;
}
